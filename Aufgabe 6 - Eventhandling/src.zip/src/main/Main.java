package main;

import java.awt.Frame;

import gui.MyGUI;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Frame frame = new MyGUI();
		frame.repaint();
	}

}
